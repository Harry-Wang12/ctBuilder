function G=bldWeightMatrix2(F,G0,G1,delta)
G=delta*ones(size(G0));
G(find(G0))=G1(find(G0));