function F0=bldFlowNet(G0,source,sink,L)
%%% Initialize flow network
F0=zeros(L,length(G0)); 

F0(1,source)=1;
F0(L,sink)=1;

F01=F0;
F02=F0;
%%% Forward construction of flow network
for i=1:L-2
    x1=find(F01(i,:));
    for j=1:length(x1)
        x2=find(G0(x1(j),:));
        F01(i+1,x2)=1;
    end
end


%%% Backward construction of flow network
for i=L:-1:2
    x1=find(F02(i,:));
    for j=1:length(x1)
        x2=find(G0(x1(j),:));
        F02(i-1,x2)=1;
    end
end

F0=double(F01 & F02);

