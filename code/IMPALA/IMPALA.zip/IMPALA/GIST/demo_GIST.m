clc;clear;close all;
%% Gibbs sampler Infers Signal Transduction (GIST)
%% GIST demo using breast cancer drug treated dataset from Loi et al.
%% fix random seed (optional)
randn('seed',3);
rand('seed',3);

%% load data summarized from Loi
fprintf('Loading dataset....');
load('demo_data.mat');
L=8;%% pathway length
node=G_symbol;
N=length(node);
fprintf('Done!\n');

%%%%%%%%%%%%%%%%%
%% Preprocessing 
%%%%%%%%%%%%%%%%%
fprintf('Preprocessing starts...\n');

%% Assign sources nodes and sink nodes
fprintf('1. Specifying source and target nodes...');
%% ER signaling starts from estrogen receptor (ESR1)
srcNode={'ESR1'};
%% Transcription factors related to ER signaling (identified from GibbsOS or alternative methods)
snkNode={'CEBPB';'CREB1';'STAT3';'STAT5A';'STAT1';'ELK1';'FOS';'JUN';'ETS1'};
fprintf('Done!\n');


%% Construct Flow Network between given source(s) and sink(s) for pathway of size L
fprintf('2. Build flow network...');
[common,ia ib]=intersect(node,srcNode);
source=ia;
[common,ia ib]=intersect(node,snkNode);
sink=ia;
F0=bldFlowNet(G0,source,sink,L);%%% Build flow network F0
fprintf('Done!\n');

%% weight the flow network
fprintf('3. Re-weighting edges in flow network...');
delta=min(min(min(G1)),0);%%% Set weight for pseudo-edges
G=bldWeightMatrix(F0,G0,G1,delta);%%% Build directed weighted matrix for given graph
fprintf('Done!\n');

%%% Set node weight
fprintf('4. Set node weight...');
H=G_nodez';
fprintf('Done!\n');

fprintf('Preprocessing completed!\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Initialization            %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Random initialization...\n');
[S V W valid_path valid_edge]=rndInitial(G,G0,F0,H,L);  %%% Random Initialization, pseudo-edges are introduced
fprintf('Initialiation completed!\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Gibbs sampler Infers Signal Transduction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% set paramters 
tic
ite=10000; % number of iterations
T=1;%% temperature
rho1=10;%% flow parameter
rho2=4;%% subcellular balance parameter
VBITE=5000;%% verbosity parameter

fprintf('Setting GIST parameters:\n');
fprintf('1. number of iterations:%d\n',ite);
fprintf('2. temperature:%d\n',T);
fprintf('3. flow parameter rho1:%d\n',rho1);
fprintf('4. subcellular balance parameter rho2:%d\n',rho2);
fprintf('5. verbosity level: %d iterations\n',VBITE);

[sampledPaths,pathFreq,pathScore]=gist(G,G0,G_locn,L,F0,H,V,W,S,valid_path,valid_edge,ite,T,rho1,rho2,VBITE);
toc;

%% sorting recorded pathways samples
fprintf('Sorting pathway samples...');
%% sorting pathways according to sampling frequency (alternative sorting method)
[rankedPathFreq freqRank]=sort(pathFreq,'descend');
rankedSampledPaths=sampledPaths(freqRank,:);
rankedPathScore=pathScore(freqRank,:);
rankedPathSymb=G_symbol(rankedSampledPaths);

%% sorting pathways according to pathway likelihood potential (preferred sorting method)
[rankedPathScore1 scoreRank]=sort(pathScore,'descend');
rankedSampledPaths1=sampledPaths(scoreRank,:);
rankedPathFreq1=pathFreq(scoreRank,:);
rankedPathSymb1=G_symbol(rankedSampledPaths1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Estimating edge probabilities
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Estimating edge probability...\n');
PATHNUM=200;
fprintf('Top %d pathways are selected for edge estimation\n',PATHNUM);

[Eg1 Eg2 Eg3 gist_slist gist_wlist gist_locn gist_flow]=est_edge(rankedSampledPaths1,rankedPathScore1,G,G_locn,PATHNUM);

%% select directed edges 
cutoff=PATHNUM;
[ia ib]=find(Eg1>rankedPathScore1(cutoff) & Eg2>0);

tmp=cell(1,5);
network=[];%% edge pairs (cytoscape in put)
for i=1:length(ia)
    tmp{1,1}=G_symbol{ia(i)};
    tmp{1,2}=G_symbol{ib(i)};
    tmp{1,3}=num2str(Eg2(ia(i),ib(i)));
    tmp{1,4}=num2str(Eg3(ia(i),ib(i)));
    network=[network;tmp];
end


%% node score is tyhe summation of all edges' score that contains this node
G_nscore=zeros(length(G_symbol),1);
for i=1:length(G_nscore)
    idx=find(sum((gist_slist==i),2));
    if ~isempty(idx)
        G_nscore(i,1)=sum(gist_wlist(idx));
    end
    
end


filename_mat='demo_results.mat';
filename_node='demo_node_attr.xlsx';
filename_network='demo_network.xlsx';

save(filename_mat,'Eg2','Eg3','network','G_symbol','G_entrez','G_loc','G_locn','G_fld','G_p','G_nscore','rankedPathScore1','rankedSampledPaths1','rankedPathSymb1');

if exist(filename_node, 'file')
    delete(filename_node,filename_network);
    fprintf('Old results deleted\n');
end

%% save node attributes to xlsx file

fprintf('Saving node attributes to .xlsx file ...');
xlswrite(filename_node,G_symbol,'sheet1','A1');
xlswrite(filename_node,G_fld,'sheet1','B1');
xlswrite(filename_node,G_p,'sheet1','C1');
xlswrite(filename_node,G_loc,'sheet1','D1');
xlswrite(filename_node,G_nscore,'sheet1','E1');
fprintf('Done!\n');
%% save network to xlsx file
fprintf('Saving network to .xlsx file ...');
xlswrite(filename_network,network,'sheet1','A1');
fprintf('Done!\n');
fprintf('GIST algorithm completed!\n');



