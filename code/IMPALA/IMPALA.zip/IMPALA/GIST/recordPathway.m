function [newSampledPaths newPathFreq newPathScore]=recordPathway(sampledPaths,pathFreq,pathScore,newPath,newScore)

idx=zeros(size(sampledPaths));
for i=1:size(sampledPaths,2)
    idx(:,i)=(sampledPaths(:,i)==newPath(i));
end

idx=sum(idx,2);

pathid=find(idx==length(newPath));

if ~isempty(pathid)
    pathFreq(pathid)=pathFreq(pathid,1)+1;
else
    sampledPaths(size(sampledPaths,1)+1,:)=newPath; 
    pathFreq(size(sampledPaths,1),1)=1;
    pathScore(size(sampledPaths,1),1)=newScore;
end

newSampledPaths=sampledPaths;
newPathFreq=pathFreq;
newPathScore=pathScore;