function index=dicing(prob)
index=0;
space=zeros(size(prob));
start=0;
for i=1:size(prob,2)
    space(i)=start+prob(i);
    start=space(i);
end

D=rand(1);


for i=1:size(space,2)
    if D<=space(i)
        index=i;
        break;
    end  
end
