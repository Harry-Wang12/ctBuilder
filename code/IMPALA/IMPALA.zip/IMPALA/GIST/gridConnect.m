function [A node]=gridConnect(N)
A=sparse(N,N);
node=[1:N^2]';
for i=1:N
    for j=1:N
        if j-1>=1
            node1=N*(i-1)+j;
            node2=N*(i-1)+j-1;
            A(node1,node2)=1;
            A(node2,node1)=1;
        end
        if j+1<=N
            node1=N*(i-1)+j;
            node2=N*(i-1)+j+1;
            A(node1,node2)=1;
            A(node2,node1)=1;
        end
        if i-1>=1
            node1=N*(i-1)+j;
            node2=N*(i-1)+j-N;
            A(node1,node2)=1;
            A(node2,node1)=1;
        end
        if i+1<=N
            node1=N*(i-1)+j;
            node2=N*(i-1)+j+N;
            A(node1,node2)=1;
            A(node2,node1)=1;
        end
    end
end