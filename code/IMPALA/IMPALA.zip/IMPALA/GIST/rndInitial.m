function [S V W valid_path valid_edge]=rndInitial(G,G0,F,H,L)
S=zeros(1,L);

while length(S)~=length(unique(S)) %%% Constraint: any protein will appear at most once in a pathway. Feedback structure is not considered in current study
    for i=1:size(F,1)
        fi=find(F(i,:));
        permidx=randperm(length(fi));
        S(i)=fi(permidx(1));
    end
end

%% calculating node and edge potential for initial pathway S
W=0;%% edge potential
V=0;%% node potential
for i=1:(L-1)
    V=V+H(S(i));
    W=W+G(S(i),S(i+1));
end
V=V+H(S(end));


valid_path=1;%% a pathway is valid if none of its edge are pseudo-edges
valid_edge=ones(1,length(S)-1);
for k=1:L-1
    if G0(S(k),S(k+1))==0
        valid_edge(k)=0;
        valid_path=0;
    end
end