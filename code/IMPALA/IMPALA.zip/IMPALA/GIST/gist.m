function [sampledPaths,pathFreq,pathScore]=gist(G,G0,G_locn,L,F0,H,V,W,S,valid_path,valid_edge,ite,T,rho1,rho2,VBITE)
%% record pathway samples
sampledPaths=[];
pathFreq=[];
pathScore=[];
%% start Gibbs sampling on flow network
fprintf('GIST algorithm: Gibbs sampling on flow network starts...\n');
for i=1:ite
    if floor((i-1)/VBITE)==((i-1)/VBITE)
        fprintf('iteration %d-%d\n',i,i+VBITE-1);
    end

    for j=1:L
        %% find candidate nodes in layer j
        s=find(F0(j,:));
        s=setdiff(s,S);
        s=union(s,S(j));
        
        S0=repmat(S',1,length(s));
        S0(j,:)=s;
        
        locdiff=zeros(1,size(S0,2));%% inconsistent location
        for k=1:(size(S0,1)-1)
            R=G_locn(S0);
            locdiff=locdiff+double((R(k+1,:)-R(k,:))>=0);
        end
        locbalance=sum(G_locn(S0)<4);
        u=rho1*locdiff+rho2*locbalance;%% flow potential=inconsistent location + subcellular balance
        
        %% update node and edge potential
        deltaW=zeros(1,length(s));
        deltaV=zeros(1,length(s));
        if j==1
            deltaW=G(s,S(j+1))'-G(S(j),S(j+1));
           
        elseif j==L
            deltaW=G(S(j-1),s)-G(S(j-1),S(j));
            
        else
            deltaW=G(s,S(j+1))'-G(S(j),S(j+1))+G(S(j-1),s)-G(S(j-1),S(j));
            
        end
        
        deltaV=H(s)-H(S(j));
        
        w=W+deltaW;
        v=V+deltaV;
        U=w+v+u;%% pathway potential
        U1=w+v;%% pathway likelihood potential
        
        %% probabilistic sampling of pathways
        prob=exp(U/T)/sum(exp(U/T));
        
        selected=dicing(prob);
        S(j)=s(selected);
        W=w(selected);
        V=v(selected);
        
        %% check id sampled pathway is valid (does NOT contain pseudo edge)
        if j==1
            valid_edge(j)=double(G0(S(j),S(j+1))==1);
        elseif j==L
            valid_edge(j-1)=double(G0(S(j-1),S(j))==1);
        else
            valid_edge(j)=double(G0(S(j),S(j+1))==1);
            valid_edge(j-1)=double(G0(S(j-1),S(j))==1);
        end
        valid_path=double(sum(valid_edge)==L-1);
        if valid_path==1 %% record only valid pathway
            [sampledPaths,pathFreq,pathScore]=recordPathway(sampledPaths,pathFreq,pathScore,S,U1(selected));
        end
        
    end
    
end
fprintf('Gibbs sampling on flow network completed!\n');
