function [Eg1 Eg2 Eg3 gist_slist gist_wlist gist_locn gist_flow]=est_edge(rankedSampledPaths1,rankedPathScore1,G,G_locn,PATHNUM)
fprintf('Calculating edge score and directions...\n');
gist_slist=rankedSampledPaths1(1:PATHNUM,:);
gist_wlist=rankedPathScore1(1:PATHNUM);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gist_locn=G_locn(rankedSampledPaths1(1:PATHNUM,:));
gist_flow=zeros(size(gist_locn,1),1);
for i=1:size(gist_locn)
    for j=2:size(gist_locn,2)
        if gist_locn(i,j-1)>gist_locn(i,j)
            gist_flow(i)=gist_flow(i)+1;
            continue;
        end
    end
end

%% delete pathways with in consistent flows (optional)
incons_id=find(gist_flow>0);
gist_slist(incons_id,:)=[];
gist_wlist(incons_id,:)=[];
gist_locn(incons_id,:)=[];
gist_flow(incons_id,:)=[];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gist_Eg=zeros(size(G));%% raw pathway score summarized from top pathways
for i=1:size(gist_slist,1)
    for j=1:(size(gist_slist,2)-1)
        gist_Eg(gist_slist(i,j),gist_slist(i,j+1))=gist_Eg(gist_slist(i,j),gist_slist(i,j+1))+gist_wlist(i);
    end
end

Eg=gist_Eg;
Eg2=gist_Eg;%% edge direction probability
for i=1:size(G,1)
    for j=(i+1):size(G,2)
        if Eg(i,j)~=0 | Eg(j,i)~=0
            if Eg(i,j)>Eg(j,i)
                Eg2(i,j)=Eg(i,j)/(Eg(i,j)+Eg(j,i));
                Eg2(j,i)=0;
            else
                Eg2(j,i)=Eg(j,i)/(Eg(i,j)+Eg(j,i));
                Eg2(i,j)=0;
            end
        end
    end
end
%%
Eg1=Eg;%% edge direction inferred (winner taks all)
for i=1:size(G,1)
    for j=(i+1):size(G,2)
        if Eg(i,j)~=0 | Eg(j,i)~=0
            if Eg(i,j)>Eg(j,i)
                Eg(j,i)==0;
            else
                Eg(i,j)=0;
            end
        end
    end
end

%% normalized edge score Eg3
Eg3=gist_Eg;
Eg3=Eg3/sum(gist_wlist);

fprintf('Calculation completed\n');


