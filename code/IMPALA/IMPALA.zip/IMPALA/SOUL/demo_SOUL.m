clc;clear;close all hidden;
%% Structural Organization Uncovers pathway Landscape (SOUL)
%% SOUL demo combining sampled pathways from three case studies:
%% 1. ER signaling
%% 2. Cell cycle
%% 3. Apoptosis

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load and merge datasets from three case studies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Loading GIST results from three case studies...\n');
N1=200;N2=100;N3=100;L=8;
gist_wlist=[];
gist_symb=[];
gist_locn=[];
gist_loc=[];
G_symb_piled=[];
G_fld_piled=[];
G_p_piled=[];
G_loc_piled=[];
%%% Merge data and results from different case studies
fprintf('1.Loading ER signaling pathways from GIST...');
load('ER_signaling.mat');
fprintf('Done!\n');
gist_wlist=[gist_wlist;rankedPathScore1(1:N1)];
gist_symb=[gist_symb;rankedPathSymb1(1:N1,:)];

tmp_pathidlist=rankedSampledPaths1(1:N1,:);
gist_locn=[gist_locn;G_locn(tmp_pathidlist)];
gist_loc=[gist_loc;G_loc(tmp_pathidlist)];

G_symb_piled=[G_symb_piled;G_symbol];
G_fld_piled=[G_fld_piled;G_fld];
G_p_piled=[G_p_piled;G_p];
G_loc_piled=[G_loc_piled;G_loc];

fprintf('2.Loading apoptosis pathways from GIST...');
load('apoptosis.mat');
fprintf('Done!\n');
gist_wlist=[gist_wlist;rankedPathScore1(1:N2)];
gist_symb=[gist_symb;rankedPathSymb1(1:N2,:)];

tmp_pathidlist=rankedSampledPaths1(1:N2,:);
gist_locn=[gist_locn;G_locn(tmp_pathidlist)];
gist_loc=[gist_loc;G_loc(tmp_pathidlist)];

G_symb_piled=[G_symb_piled;G_symbol];
G_fld_piled=[G_fld_piled;G_fld];
G_p_piled=[G_p_piled;G_p];
G_loc_piled=[G_loc_piled;G_loc];

fprintf('3.Loading cell cycle pathways from GIST...');
load('cell_cycle.mat');
fprintf('Done!\n');

gist_wlist=[gist_wlist;rankedPathScore1(1:N3)];
gist_symb=[gist_symb;rankedPathSymb1(1:N3,:)];

tmp_pathidlist=rankedSampledPaths1(1:N3,:);
gist_locn=[gist_locn;G_locn(tmp_pathidlist)];
gist_loc=[gist_loc;G_loc(tmp_pathidlist)];

G_symb_piled=[G_symb_piled;G_symbol];
G_fld_piled=[G_fld_piled;G_fld];
G_p_piled=[G_p_piled;G_p];
G_loc_piled=[G_loc_piled;G_loc];

%%% check pathway flow
fprintf('Checking pathway flow and deleting pathways of inconsistent flow...');
gist_flow=zeros(size(gist_locn,1),1);
for i=1:size(gist_locn)
    for j=2:size(gist_locn,2)
        if gist_locn(i,j-1)>gist_locn(i,j)
            gist_flow(i)=gist_flow(i)+1;
            continue;
        end
    end
end

incons_id=find(gist_flow>0);
gist_symb(incons_id,:)=[];
gist_wlist(incons_id,:)=[];
gist_locn(incons_id,:)=[];
gist_flow(incons_id,:)=[];
fprintf('Done!\n');




%% merged symbol and attributes
G_symb_merged=unique(gist_symb(:));
G_fld_merged=zeros(size(G_symb_merged));
G_p_merged=zeros(size(G_symb_merged));
G_loc_merged=cell(size(G_symb_merged));
for i=1:length(G_symb_merged)
    id=find(strcmp(G_symb_piled,G_symb_merged{i}));
    G_fld_merged(i)=G_fld_piled(id(1));
    G_p_merged(i)=G_p_piled(id(1));
    G_loc_merged(i)=G_loc_piled(id(1));
end
%% new pathway id list in merged dataset
gist_slist=zeros(size(gist_symb));
for i=1:size(gist_slist,1)
    for j=1:size(gist_slist,2)
        id=find(strcmp(G_symb_merged,gist_symb{i,j}));
        gist_slist(i,j)=id;
    end
end

%% recalculate node score based on merged pathway results
G_nscore_merged=zeros(length(G_symb_merged),1);
for i=1:length(G_nscore_merged)
    idx=find(sum((gist_slist==i),2));
    if ~isempty(idx)
        G_nscore_merged(i,1)=sum(gist_wlist(idx));
    end    
end
fprintf('Loading and merging pathway results completed!\n');

%%%%%%%%%%%%%%%%%%%%%%%%
%% edge distribution
%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Calculating edge attributes...\n');
gist_Eg=zeros(size(G_symb_merged,1));
for i=1:size(gist_slist,1)
    for j=1:(size(gist_slist,2)-1)
        gist_Eg(gist_slist(i,j),gist_slist(i,j+1))=gist_Eg(gist_slist(i,j),gist_slist(i,j+1))+gist_wlist(i);
    end
end

fprintf('1.Calculating edge direction probability...');
Eg=gist_Eg;
Eg2=gist_Eg;%% edge direction probability
for i=1:size(G_symb_merged,1)
    for j=(i+1):size(G_symb_merged,1)
        if Eg(i,j)~=0 | Eg(j,i)~=0
            Eg2(i,j)=Eg(i,j)/(Eg(i,j)+Eg(j,i));
            Eg2(j,i)=Eg(j,i)/(Eg(i,j)+Eg(j,i));
        end
    end
end
fprintf('Done!\n');

fprintf('2.Calculating normalized edge score...');
for i=1:size(G_symb_merged,1)
    for j=(i+1):size(G_symb_merged,2)
        if Eg(i,j)~=0 | Eg(j,i)~=0
            if Eg(i,j)>Eg(j,i)
                Eg(j,i)==0;
            else
                Eg(i,j)=0;
            end
        end
    end
end
Eg3=gist_Eg;
Eg3=Eg3/sum(gist_wlist);
fprintf('Done!\n');





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Structural Organization Uncovers pathway Landscape (SOUL)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('SOUL algorithm start...\n');
%% structrual clustering
fprintf('1. Calculating structural profile...');
TOTALNUM=size(gist_symb,1);
dis=zeros(TOTALNUM);
score=zeros(TOTALNUM,1);

for i=1:size(dis,1)
    for j=(i+1):size(dis,1)
        dis(i,j)=length(intersect(gist_symb(i,:),gist_symb(j,:)));
        dis(j,i)=dis(i,j);
    end
end
fprintf('Done!\n');
fprintf('2. Clustering based on structural profile...');
if ~exist('collabels3.mat', 'file')
    cgo=clustergram(dis,'Standardize',3,'DisplayRange',10);
    
    get(cgo);
    
    collabels=cgo.ColumnLabels;
    save('collabls3.mat','collabels');
else
    load('collabels3.mat');
end
clabel=[];
for i=1:length(collabels)
    clabel=[clabel;str2num(collabels{i})];
end
fprintf('Done!\n');
fprintf('3. Re-organizing pathway samples and potential distribution...');
gist_symb_sorted=gist_symb(clabel,:);
gist_wlist_sorted=gist_wlist(clabel,:);
gist_slist_sorted=gist_slist(clabel,:);
gist_loc_sorted=gist_loc(clabel,:);
gist_locn_sorted=gist_locn(clabel,:);
dis_sorted=dis(clabel,clabel);
fprintf('Done!\n');
smp=0.04;%% smoothing parameter
fprintf('4. Smoothing potential distribution (smoothing parameter = %d)...',smp);
score_sorted=gist_wlist_sorted;
score_sm_sorted=smooth(score_sorted,smp);%% smooth pathway potential distribution
fprintf('Done!\n');
figure;imagesc (dis_sorted); figure(gcf);
figure;area (score_sm_sorted, 'DisplayName', 'score_sorted', 'YDataSource', 'score_sorted'); figure(gcf)
axis([0 400 19 30])
% figure;plot(score_sorted);

%% select clusters of interest
%% four clusters in manuscript: "Unraveling the intracellular signal 
%% transduction and pathway crosstalk by exploring pathway landscape" by Gu et al.
%% are selected as an example.
fprintf('5. Selecting pathway modules of interest...');
cluster1_id=[10:22];
cluster1_gene=unique(gist_symb_sorted(cluster1_id,:));
cluster2_id=[160:168];
cluster2_gene=unique(gist_symb_sorted(cluster2_id,:));
cluster3_id=[230:240];
cluster3_gene=unique(gist_symb_sorted(cluster3_id,:));
cluster4_id=[348:360];
cluster4_gene=unique(gist_symb_sorted(cluster4_id,:));

postgist_symb_id=[10:22 160:168 230:240 348:360]';
postgist_symb=gist_symb_sorted(postgist_symb_id,:);
postgist_slist=gist_slist_sorted(postgist_symb_id,:);
Epg2=zeros(size(Eg2));
Epg3=zeros(size(Eg3));

for i=1:size(postgist_slist,1)
    for j=1:size(postgist_slist,2)-1
        if Epg2(postgist_slist(i,j),postgist_slist(i,j+1))==0
            Epg2(postgist_slist(i,j),postgist_slist(i,j+1))=Eg2(postgist_slist(i,j),postgist_slist(i,j+1));
            Epg3(postgist_slist(i,j),postgist_slist(i,j+1))=Eg3(postgist_slist(i,j),postgist_slist(i,j+1));
        end
    end
end
fprintf('Done!\n');
[ia ib]=find(Epg2>0);
%% calculate betweeness centrality
% fprintf('6. Calculating betweeness centrality...');
% [bc symb_bc]=network_bc([G_symb_merged(ia) G_symb_merged(ib)]);
fprintf('Done!\n');
tmp=cell(1,4);
network=[];
for i=1:length(ia)
    tmp{1,1}=G_symb_merged{ia(i)};%% gene symbol 1
    tmp{1,2}=G_symb_merged{ib(i)};%% gene symbol 2
    tmp{1,3}=num2str(Epg2(ia(i),ib(i)));%% edge direction probability
    tmp{1,4}=num2str(Epg3(ia(i),ib(i)));%% normailized edge score
    network=[network;tmp];
end


fprintf('Save node attributes to .xlsx file...');
filename_node='SOUL_nodes_bidir.xlsx';
idx=union(ia,ib);
if exist(filename_node,'file')
    delete(filename_node);
end
xlswrite(filename_node,G_symb_merged(idx),'sheet1','A1');%% gene symbol
xlswrite(filename_node,G_fld_merged(idx),'sheet1','B1');%% fold change
xlswrite(filename_node,G_p_merged(idx),'sheet1','C1');%% node p-value
xlswrite(filename_node,G_loc_merged(idx),'sheet1','D1');%% subcellular location
xlswrite(filename_node,G_nscore_merged(idx),'sheet1','E1');%% node score
% G_bc=zeros(length(idx),1);
% for i=1:length(idx)
%     ia=find(strcmp(symb_bc,G_symb_merged(idx(i))));
%     G_bc(i)=bc(ia);
% end
% xlswrite(filename_node,G_bc,'sheet1','F1');%% betweeness centrality
fprintf('Done!\n');
fprintf('Save network to .xlsx file...');
filename_network='SOUL_network_bidir.xlsx';
if exist(filename_network,'file')
    delete(filename_network);
end
xlswrite(filename_network,network,'sheet1','A1');
fprintf('Done!\n');
fprintf('SOUL demo completed!\n');
